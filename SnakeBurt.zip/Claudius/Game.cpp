//Daniel Burt, 08/11/2019
//Revised      15/01/2022

#include "Game.h"
#include <algorithm>
#include <iostream>

bool Game::update([[maybe_unused]]float dt)
{
	if (!started) //Spares me a constructor, rule of zero
	{
		apple_coords = get_random_free_space();
		started = true;
	}

	if (snake.empty()) return false;

	if (snake.is_alive())
	{
		if (!in_bounds(snake.head_coords()) || snake.colliding_with_self())
		{
			snake.die();
			if(!won)
				std::cout << "Game Over!\nYour snake reached a length of:\n" << snake.length() << '\n';
			else
				std::cout << "Wow! I can't believe you won.\nYour snake reached a length of:\n" << snake.length() << '\n';
			return true;
		}
	}
	if (snake.head_coords() == apple_coords)
	{
		snake.add_part();
		apple_coords = get_random_free_space();
	}
	snake.update();
	return true;
}

constexpr int GUESSES = 5;
Coords Game::get_random_free_space()
{
	//cheap but not guaranteed
	for (size_t guess = 0; guess < GUESSES; guess++)
	{
		Coords test_coord(rand() % GRID_WIDTH, rand() % GRID_HEIGHT);
		if (std::none_of(snake.snake_part_coords.begin(), snake.snake_part_coords.end(), [test_coord](const Coords& part_coord) noexcept 
		{ 
			return test_coord == part_coord; 
		}))
			return test_coord;
	}
	//costly but guaranteed
	return get_guanateed_free_space();
}

Coords Game::get_guanateed_free_space()
{
	std::vector<Coords> available_squares;
	available_squares.reserve(GRID_HEIGHT * GRID_WIDTH - snake.length());
	//indexes matter
	for (int y = 0; y < GRID_HEIGHT; y++)
	{
		for (int x = 0; x < GRID_WIDTH; x++)
		{
			const auto coord = Coords(x, y);
			if (std::none_of(snake.snake_part_coords.begin(), snake.snake_part_coords.end(), [coord](const Coords& part_coord) noexcept { return coord == part_coord; }))
			{
				available_squares.push_back(coord);
			}
		}
	}
	if (available_squares.empty())
	{
		won = true;
		return Coords{};
	}
	//generating random numbers using the "modern" mt19937 stuff is less clean or readable in my view
	return available_squares.at(rand() % available_squares.size());
}

void Game::render_objects(Renderer& renderer)
{
	renderer.render(generate_grid_cell(apple_coords), APPLE_COLOR);
	for (auto& part : snake.snake_part_coords)
	{
		renderer.render(generate_grid_cell(part), SNAKE_COLOR);
	}
}

void Game::OnKeyDown(const KeyCode key) noexcept
{
	snake.on_key_down(key);
}


bool Game::in_bounds(const Coords & coords) const noexcept
{
	return coords.x >= 0 && coords.x < GRID_WIDTH && coords.y >= 0 && coords.y < GRID_HEIGHT;
}

inline Rectangle Game::generate_grid_cell(const Coords& coords) const noexcept
{
	return Rectangle(coords.x * SQUARE_SIZE, coords.y * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE);
}
