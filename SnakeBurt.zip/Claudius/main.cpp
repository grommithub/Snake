﻿#include "Game.h"
#include "Constants.h"
#include <iostream>
#include "KeyCode.h"
#pragma warning(push)
#include <CodeAnalysis/Warnings.h>
#pragma warning(disable:ALL_CODE_ANALYSIS_WARNINGS)
#pragma warning (pop)

#undef main

bool gather_user_events(Game& game) noexcept
{
	SDL_Event e;
	while (SDL_PollEvent(&e))
	{
		switch (e.type)
		{
			case SDL_QUIT:    return false;
			case SDL_KEYDOWN: game.OnKeyDown(TranslateKeyCode(e.key.keysym.sym)); continue;
			default:break;
		}
	}
	return true;
}

struct UpdateTimer
{
	float        sec_delta_time  = 0.0f;
	unsigned int ms_last_frame   = 0;
	unsigned int ms_time_to_wait = 0;

	void wait_for_time_to_update() noexcept
	{
		SDL_Delay(calculate_wait_time());
	}

	unsigned int calculate_wait_time() noexcept
	{ 
		ms_time_to_wait = SDL_GetTicks() - ms_last_frame + (MS_BETWEEN_FRAMES);
		return ms_time_to_wait;
	}
	float get_seconds_delta_time() const noexcept
	{
		return static_cast<float>(ms_time_to_wait) / 1000.0f;
	}
	void on_frame_complete() noexcept
	{
		ms_last_frame = SDL_GetTicks();
	}
};

void seed_random();

int main()
{
	//Good idea taken from Elin
	try
	{
		SDL_Initializer init;
		Window window;
		Renderer renderer(window);
		Game game;
		UpdateTimer timer;

		seed_random();

		while (true)
		{
			timer.wait_for_time_to_update();

			if (!gather_user_events(game)) break;
			if (!game.update(timer.get_seconds_delta_time())) break;

			game.render_objects(renderer);
			renderer.present();

			timer.on_frame_complete();
		}
	}
	catch (const std::exception& e)
	{
		std::cout << "Fatal Error!\n" << e.what() << std::endl;
		return -1;
	}
	catch (...)
	{
		std::cout << "Unknown Fatal Error!" << std::endl;
		return -1;
	}
	return 0;
}


#pragma warning(push)
#pragma warning(disable:ALL_CODE_ANALYSIS_WARNINGS)
//I would use gsl_narrow but the gsl nuget package is deprecated and generates errors
void seed_random()
{
	srand(static_cast<unsigned int>(time(nullptr)));
}
#pragma warning (pop)
