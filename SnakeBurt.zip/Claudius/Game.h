#pragma once
#include <vector>
#include "SDL_Resources.h"
#include "Snake.h"

class Game
{
	Snake snake;
	Coords apple_coords;
	bool started = false;
	bool won     = false;

	Coords get_random_free_space(); //There's a one in a trillion chance this flips a bool so it's not const
	Coords get_guanateed_free_space();
	bool in_bounds(const Coords& coords) const noexcept;
	Rectangle generate_grid_cell(const Coords& coords) const noexcept;
public:
	bool update(float dt);
	void render_objects(Renderer& rendererManager);

	void OnKeyDown(const KeyCode key) noexcept;
};