#pragma once

#include "Coords.h"
#include "Rectangle.h"
#include <vector>
#include "KeyCode.h"
#include "Constants.h"

class Snake
{
private:

	void move_head();
	void update_snake_part_positions();
	
	bool dead = false;
	Direction current_direction = Direction::LEFT;
	Direction next_direction    = Direction::LEFT;

public:
	Snake() noexcept;
	void update();
	inline Coords& head_coords() noexcept;

	void add_part();
	bool colliding_with_self() noexcept;
	void die() noexcept;

	size_t length() const noexcept;
	bool empty() const noexcept;
	std::vector<Coords> snake_part_coords;
	void on_key_down(const KeyCode key) noexcept;
	bool is_alive() const noexcept;
};
