#pragma once
struct Rectangle
{
	int x{}, y{}, w{}, h{};
};