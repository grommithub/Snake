#pragma once

struct Color
{
	unsigned char r{}, g{}, b{}, a{};
};