#pragma once

#include <stdexcept>
#include "Constants.h"
#include "Rectangle.h"
#include <iostream>

#pragma warning(push)
#include <CodeAnalysis/Warnings.h>
#pragma warning(disable:ALL_CODE_ANALYSIS_WARNINGS)
#include "SDL.h"
#pragma warning(pop)


// Good idea stolen from Elin
struct SDL_Initializer
{
	SDL_Initializer() noexcept(false)
	{
		if (SDL_Init(SDL_INIT_EVERYTHING) < 0)
		{
			throw std::runtime_error(SDL_GetError());
		}
	}
	~SDL_Initializer()
	{
		try
		{
			std::cout << "Quitting SDL.." << '\n';
		}
		catch (...){}
		SDL_Quit();
	}
	SDL_Initializer(const SDL_Initializer&) = delete;
	SDL_Initializer& operator=(const SDL_Initializer&) = delete;
	SDL_Initializer(SDL_Initializer&&) = delete;
	SDL_Initializer& operator=(SDL_Initializer&&) = delete;
};

struct Window
{
	SDL_Window* window = nullptr;
	Window() noexcept(false)
	{
		window = SDL_CreateWindow(WINDOW_NAME.data(), 100, 100, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WindowFlags::SDL_WINDOW_RESIZABLE);
		if (window == nullptr)
		{
			throw(std::runtime_error(SDL_GetError()));
		}
	}
	~Window() noexcept(false)
	{
		std::cout << "Destroying Window.." << '\n';
		SDL_DestroyWindow(window);
	}
	Window(const Window&) = delete;
	Window& operator=(const Window&) = delete;
	Window(Window&&) = delete;
	Window& operator=(Window&&) = delete;
};

class Renderer
{
private:
	struct RectEntry
	{
		Rectangle rect;
		Color color;
		SDL_Rect to_sdl_rect() const noexcept
		{
			return SDL_Rect(rect.x, rect.y, rect.w, rect.h);
		}
	};
	std::vector<RectEntry> rect_entries;
	void render_rect_entry(const RectEntry entry) noexcept
	{
		SDL_SetRenderDrawColor(renderer, entry.color.r, entry.color.g, entry.color.b, entry.color.a);
		const auto rect = entry.to_sdl_rect();
		if(FILLED_SQUARE)
			SDL_RenderFillRect(renderer, &rect);
		else
			SDL_RenderDrawRect(renderer, &rect);
	}
	SDL_Renderer* renderer;
public:
	void render(const Rectangle rect, const Color color)
	{
		rect_entries.push_back({rect, color});
	}
	void present() noexcept
	{
		SDL_SetRenderDrawColor(renderer, BACKGROUND_COLOR.r, BACKGROUND_COLOR.g, BACKGROUND_COLOR.b, BACKGROUND_COLOR.a);
		SDL_RenderClear(renderer);
		for (auto&& rect_entry : rect_entries)
		{
			render_rect_entry(rect_entry);
		}
		SDL_RenderPresent(renderer);
		rect_entries.clear();
	}

	Renderer(Window& window)
	{
		renderer = SDL_CreateRenderer(window.window, 0, SDL_RendererFlags::SDL_RENDERER_ACCELERATED);
		if (renderer == nullptr)
		{
			throw std::runtime_error(SDL_GetError());
		}
	}
	~Renderer() noexcept
	{
		try //Apparently printing can throw
		{
			std::cout << "Destroying Renderer.." << '\n';
		} catch (...){}
		SDL_DestroyRenderer(renderer);
	}
	Renderer() = delete;
	Renderer(const Renderer&) = delete;
	Renderer& operator=(const Renderer&) = delete;
	Renderer(Renderer&&) = delete;
	Renderer& operator=(Renderer&&) = delete;

};

