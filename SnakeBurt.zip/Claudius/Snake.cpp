#include "Snake.h"
#include "Coords.h"
#include "Constants.h"
#include <algorithm>

size_t Snake::length() const noexcept
{
	return snake_part_coords.size();
}

bool Snake::empty() const noexcept
{
	return snake_part_coords.empty();
}

void Snake::on_key_down(const KeyCode key) noexcept
{
	if ((key == KeyCode::W || key == KeyCode::UP_ARROW) && current_direction != Direction::DOWN)
	{
		next_direction = Direction::UP;
	}
	if ((key == KeyCode::S || key == KeyCode::DOWN_ARROW) && current_direction != Direction::UP)
	{
		next_direction = Direction::DOWN;
	}
	if ((key == KeyCode::A || key == KeyCode::LEFT_ARROW) && current_direction != Direction::RIGHT)
	{
		next_direction = Direction::LEFT;
	}
	if ((key == KeyCode::D || key == KeyCode::RIGHT_ARROW) && current_direction != Direction::LEFT)
	{
		next_direction = Direction::RIGHT;
	}
}

bool Snake::is_alive() const noexcept //lol
{
	return !dead;
}


void Snake::add_part()
{
	snake_part_coords.push_back(Coords());
	snake_part_coords.back() = snake_part_coords.at(snake_part_coords.size() - 2);
}

Snake::Snake() noexcept
{
	for (int i = 0; i < SNAKE_START_LENGTH; i++)
	{
		snake_part_coords.push_back(Coords(MIDDLE_COORDS.x + i, MIDDLE_COORDS.y));
	}
}

Coords& Snake::head_coords() noexcept
{
	return snake_part_coords.front();
}

void Snake::die() noexcept
{
	dead = true;
}

void Snake::move_head()
{
	current_direction = next_direction; 
	update_snake_part_positions();
	switch (current_direction)
	{
	case Direction::UP:
		snake_part_coords.front().y--;
		break;
	case Direction::DOWN:
		snake_part_coords.front().y++;
		break;
	case Direction::LEFT:
		snake_part_coords.front().x--;
		break;
	case Direction::RIGHT:
		snake_part_coords.front().x++;
		break;
	default:
		break;
	}
}

void Snake::update_snake_part_positions()
{
	if (snake_part_coords.size() < 2) return;
	
	for (size_t i = snake_part_coords.size() - 1; i > 0; i--) //index is used
	{
		snake_part_coords.at(i) = snake_part_coords.at(i - 1);
	}
}

bool Snake::colliding_with_self() noexcept
{
	for (auto& part : snake_part_coords)
	{
		if (&part == &head_coords()) continue;
		if (head_coords() == part)
		{
			return true;
		}
	}
	return false;
}


void Snake::update()
{
	if (dead)
	{
		if(!snake_part_coords.empty()) snake_part_coords.pop_back();
		return;
	}
	move_head();
}

